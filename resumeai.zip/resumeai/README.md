# ResumeAI — Setup Guide

## Step 1: Create GitHub repo & push code

```bash
cd resumeai
git init
git add .
git commit -m "initial commit"
# Create a new repo on github.com called "resumeai"
git remote add origin https://github.com/YOUR_USERNAME/resumeai.git
git push -u origin main
```

## Step 2: Set up Supabase

1. Go to your Supabase project → SQL Editor
2. Copy and paste the contents of `supabase-schema.sql`
3. Click Run
4. Go to Project Settings → API → copy:
   - Project URL → NEXT_PUBLIC_SUPABASE_URL
   - anon public key → NEXT_PUBLIC_SUPABASE_ANON_KEY
   - service_role key → SUPABASE_SERVICE_ROLE_KEY

## Step 3: Create Stripe product

1. Stripe Dashboard → Products → Add product
2. Name: "ResumeAI Pro"
3. Price: $9.00 / month (recurring)
4. Copy the Price ID (starts with price_...) → STRIPE_PRO_PRICE_ID

## Step 4: Deploy to Vercel

1. Go to vercel.com → New Project → Import your GitHub repo
2. Add all environment variables from .env.example
3. Deploy

## Step 5: Set up Stripe webhook

1. Stripe Dashboard → Developers → Webhooks → Add endpoint
2. URL: https://YOUR-VERCEL-URL.vercel.app/api/webhook
3. Events to listen for:
   - checkout.session.completed
   - customer.subscription.deleted
   - invoice.payment_failed
4. Copy the webhook signing secret → STRIPE_WEBHOOK_SECRET
5. Add to Vercel env vars → Redeploy

## Step 6: Enable Supabase Auth

1. Supabase → Authentication → Providers
2. Enable Email provider (already on by default)
3. Optional: enable Google OAuth for easier signups

## You're live! 🚀

Test the full flow:
- Go to your Vercel URL
- Paste a resume + job description
- Click optimize
- See the result
- Try to optimize a 4th time → should show upgrade prompt
- Click upgrade → Stripe checkout → pay with test card 4242 4242 4242 4242
- Check your Supabase users table → plan should change to 'pro'
- Check your email → should receive welcome email from Resend

## Daily check (15 min/day)
- Stripe Dashboard → see new subscribers
- Supabase → users table → see signups
- That's it. Everything else is automated.
