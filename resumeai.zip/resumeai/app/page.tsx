'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'

export default function Home() {
  const [resume, setResume] = useState('')
  const [jobDesc, setJobDesc] = useState('')
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleOptimize() {
    if (!resume.trim() || !jobDesc.trim()) {
      setError('Please paste both your resume and the job description.')
      return
    }
    setLoading(true)
    setError('')
    setResult('')

    const { data: { user } } = await supabase.auth.getUser()

    const res = await fetch('/api/optimize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resume, jobDescription: jobDesc, userId: user?.id })
    })

    const data = await res.json()

    if (res.status === 402) {
      setError('You have used all 3 free optimizations. Upgrade to Pro for unlimited access.')
      setLoading(false)
      return
    }

    if (data.error) {
      setError(data.error)
    } else {
      setResult(data.result)
    }
    setLoading(false)
  }

  return (
    <main style={{
      minHeight: '100vh',
      background: '#0a0a0a',
      color: '#f0f0f0',
      fontFamily: '"DM Sans", sans-serif',
      padding: '0'
    }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Serif+Display&display=swap" rel="stylesheet"/>

      {/* Hero */}
      <div style={{ maxWidth: 900, margin: '0 auto', padding: '80px 24px 40px' }}>
        <div style={{
          display: 'inline-block',
          background: '#1a1a2e',
          border: '1px solid #2a2a4a',
          borderRadius: 100,
          padding: '6px 16px',
          fontSize: 13,
          color: '#8888ff',
          marginBottom: 24
        }}>
          AI-powered · ATS optimized · Free to start
        </div>

        <h1 style={{
          fontFamily: '"DM Serif Display", serif',
          fontSize: 'clamp(36px, 6vw, 64px)',
          fontWeight: 400,
          lineHeight: 1.1,
          margin: '0 0 20px',
          background: 'linear-gradient(135deg, #fff 0%, #aaaaff 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent'
        }}>
          Your resume, rewritten<br/>to land the job.
        </h1>

        <p style={{ color: '#888', fontSize: 18, margin: '0 0 48px', maxWidth: 520 }}>
          Paste your resume and the job description. Our AI rewrites your resume to match, beat the ATS, and get you to the interview.
        </p>

        {/* Input grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
          <div>
            <label style={{ display: 'block', fontSize: 13, color: '#666', marginBottom: 8, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
              Your resume
            </label>
            <textarea
              value={resume}
              onChange={e => setResume(e.target.value)}
              placeholder="Paste your current resume here..."
              style={{
                width: '100%',
                height: 280,
                background: '#111',
                border: '1px solid #222',
                borderRadius: 12,
                color: '#ddd',
                padding: 16,
                fontSize: 14,
                lineHeight: 1.6,
                resize: 'vertical',
                outline: 'none',
                boxSizing: 'border-box',
                fontFamily: 'inherit'
              }}
            />
          </div>
          <div>
            <label style={{ display: 'block', fontSize: 13, color: '#666', marginBottom: 8, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
              Job description
            </label>
            <textarea
              value={jobDesc}
              onChange={e => setJobDesc(e.target.value)}
              placeholder="Paste the job description you're applying for..."
              style={{
                width: '100%',
                height: 280,
                background: '#111',
                border: '1px solid #222',
                borderRadius: 12,
                color: '#ddd',
                padding: 16,
                fontSize: 14,
                lineHeight: 1.6,
                resize: 'vertical',
                outline: 'none',
                boxSizing: 'border-box',
                fontFamily: 'inherit'
              }}
            />
          </div>
        </div>

        {error && (
          <div style={{
            background: '#1a0a0a',
            border: '1px solid #441111',
            borderRadius: 10,
            padding: '12px 16px',
            color: '#ff6666',
            fontSize: 14,
            marginBottom: 16
          }}>
            {error}
            {error.includes('Upgrade') && (
              <a href="/pricing" style={{ color: '#8888ff', marginLeft: 8 }}>Upgrade to Pro →</a>
            )}
          </div>
        )}

        <button
          onClick={handleOptimize}
          disabled={loading}
          style={{
            width: '100%',
            padding: '16px 32px',
            background: loading ? '#1a1a2e' : 'linear-gradient(135deg, #4444ff, #8888ff)',
            border: 'none',
            borderRadius: 12,
            color: '#fff',
            fontSize: 16,
            fontWeight: 500,
            cursor: loading ? 'not-allowed' : 'pointer',
            fontFamily: 'inherit',
            transition: 'opacity 0.2s'
          }}
        >
          {loading ? 'Optimizing your resume...' : '✦ Optimize my resume'}
        </button>

        <p style={{ textAlign: 'center', color: '#444', fontSize: 13, margin: '12px 0 0' }}>
          3 free optimizations · No card required · Results in ~15 seconds
        </p>

        {/* Result */}
        {result && (
          <div style={{
            marginTop: 40,
            background: '#0f0f1a',
            border: '1px solid #2a2a4a',
            borderRadius: 16,
            padding: 32
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
              <h2 style={{ fontFamily: '"DM Serif Display", serif', fontWeight: 400, fontSize: 24, margin: 0 }}>
                Your optimized resume
              </h2>
              <button
                onClick={() => navigator.clipboard.writeText(result)}
                style={{
                  background: '#1a1a2e',
                  border: '1px solid #2a2a4a',
                  borderRadius: 8,
                  color: '#8888ff',
                  padding: '8px 16px',
                  cursor: 'pointer',
                  fontSize: 13,
                  fontFamily: 'inherit'
                }}
              >
                Copy result
              </button>
            </div>
            <pre style={{
              whiteSpace: 'pre-wrap',
              fontFamily: 'inherit',
              fontSize: 14,
              lineHeight: 1.8,
              color: '#ccc',
              margin: 0
            }}>
              {result}
            </pre>
          </div>
        )}

        {/* Social proof */}
        <div style={{ marginTop: 80, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {[
            { stat: '3,200+', label: 'Resumes optimized' },
            { stat: '68%', label: 'Interview rate improvement' },
            { stat: '$9/mo', label: 'Pro plan, cancel anytime' }
          ].map(({ stat, label }) => (
            <div key={stat} style={{
              background: '#111',
              border: '1px solid #1a1a1a',
              borderRadius: 12,
              padding: '24px',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: 32, fontWeight: 600, color: '#8888ff' }}>{stat}</div>
              <div style={{ fontSize: 13, color: '#555', marginTop: 4 }}>{label}</div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
