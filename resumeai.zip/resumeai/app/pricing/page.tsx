'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'

export default function Pricing() {
  const [loading, setLoading] = useState(false)

  async function handleUpgrade() {
    setLoading(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      window.location.href = '/login'
      return
    }

    const res = await fetch('/api/create-checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id, userEmail: user.email })
    })
    const { url } = await res.json()
    window.location.href = url
  }

  return (
    <main style={{
      minHeight: '100vh',
      background: '#0a0a0a',
      color: '#f0f0f0',
      fontFamily: '"DM Sans", sans-serif',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24
    }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Serif+Display&display=swap" rel="stylesheet"/>

      <div style={{ maxWidth: 700, width: '100%' }}>
        <h1 style={{
          fontFamily: '"DM Serif Display", serif',
          fontWeight: 400,
          fontSize: 48,
          textAlign: 'center',
          marginBottom: 12
        }}>Simple pricing</h1>
        <p style={{ textAlign: 'center', color: '#666', marginBottom: 48 }}>Start free. Upgrade when you're ready.</p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {/* Free */}
          <div style={{
            background: '#111',
            border: '1px solid #222',
            borderRadius: 16,
            padding: 32
          }}>
            <div style={{ fontSize: 13, color: '#666', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 16 }}>Free</div>
            <div style={{ fontSize: 48, fontWeight: 600 }}>$0</div>
            <div style={{ color: '#555', marginBottom: 32 }}>forever</div>
            {['3 resume optimizations', 'ATS score + analysis', 'Keyword gap report', 'Copy optimized resume'].map(f => (
              <div key={f} style={{ display: 'flex', gap: 10, marginBottom: 12, fontSize: 14, color: '#888' }}>
                <span style={{ color: '#444' }}>✓</span> {f}
              </div>
            ))}
            <a href="/" style={{
              display: 'block',
              textAlign: 'center',
              marginTop: 32,
              padding: '12px 24px',
              border: '1px solid #333',
              borderRadius: 10,
              color: '#666',
              textDecoration: 'none',
              fontSize: 14
            }}>Get started free</a>
          </div>

          {/* Pro */}
          <div style={{
            background: '#0f0f1a',
            border: '2px solid #4444ff',
            borderRadius: 16,
            padding: 32,
            position: 'relative'
          }}>
            <div style={{
              position: 'absolute',
              top: -12,
              left: '50%',
              transform: 'translateX(-50%)',
              background: '#4444ff',
              borderRadius: 100,
              padding: '4px 16px',
              fontSize: 12,
              fontWeight: 500,
              whiteSpace: 'nowrap'
            }}>Most popular</div>
            <div style={{ fontSize: 13, color: '#8888ff', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 16 }}>Pro</div>
            <div style={{ fontSize: 48, fontWeight: 600 }}>$9</div>
            <div style={{ color: '#555', marginBottom: 32 }}>per month · cancel anytime</div>
            {[
              'Unlimited optimizations',
              'ATS score + analysis',
              'Keyword gap report',
              'Copy optimized resume',
              'Priority AI processing',
              'Optimization history'
            ].map(f => (
              <div key={f} style={{ display: 'flex', gap: 10, marginBottom: 12, fontSize: 14, color: '#ccc' }}>
                <span style={{ color: '#8888ff' }}>✓</span> {f}
              </div>
            ))}
            <button
              onClick={handleUpgrade}
              disabled={loading}
              style={{
                display: 'block',
                width: '100%',
                marginTop: 32,
                padding: '12px 24px',
                background: 'linear-gradient(135deg, #4444ff, #8888ff)',
                border: 'none',
                borderRadius: 10,
                color: '#fff',
                fontSize: 14,
                fontWeight: 500,
                cursor: loading ? 'not-allowed' : 'pointer',
                fontFamily: 'inherit'
              }}
            >
              {loading ? 'Redirecting...' : 'Upgrade to Pro →'}
            </button>
          </div>
        </div>
      </div>
    </main>
  )
}
