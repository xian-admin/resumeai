import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'ResumeAI — Land more interviews',
  description: 'AI-powered resume optimizer. Paste your resume and job description, get an ATS-optimized resume in seconds.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0 }}>
        <nav style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          zIndex: 100,
          background: 'rgba(10,10,10,0.8)',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid #1a1a1a',
          padding: '0 24px',
          height: 56,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <a href="/" style={{
            color: '#fff',
            textDecoration: 'none',
            fontFamily: '"DM Sans", sans-serif',
            fontWeight: 600,
            fontSize: 16,
            letterSpacing: '-0.02em'
          }}>
            ✦ ResumeAI
          </a>
          <div style={{ display: 'flex', gap: 24, alignItems: 'center' }}>
            <a href="/pricing" style={{ color: '#666', textDecoration: 'none', fontSize: 14, fontFamily: '"DM Sans", sans-serif' }}>Pricing</a>
            <a href="/dashboard" style={{ color: '#666', textDecoration: 'none', fontSize: 14, fontFamily: '"DM Sans", sans-serif' }}>Dashboard</a>
            <a href="/login" style={{
              color: '#fff',
              textDecoration: 'none',
              fontSize: 14,
              fontFamily: '"DM Sans", sans-serif',
              background: '#1a1a2e',
              border: '1px solid #2a2a4a',
              borderRadius: 8,
              padding: '6px 14px'
            }}>Sign in</a>
          </div>
        </nav>
        <div style={{ paddingTop: 56 }}>
          {children}
        </div>
      </body>
    </html>
  )
}
