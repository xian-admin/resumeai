import { NextRequest, NextResponse } from 'next/server'
import { optimizeResume } from '@/lib/ai'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  try {
    const { resume, jobDescription, userId } = await req.json()

    if (!resume || !jobDescription) {
      return NextResponse.json({ error: 'Resume and job description are required' }, { status: 400 })
    }

    // Check usage limit for free users
    if (userId) {
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('plan, optimizations_used')
        .eq('id', userId)
        .single()

      if (user && user.plan === 'free' && user.optimizations_used >= 3) {
        return NextResponse.json(
          { error: 'Free limit reached. Upgrade to Pro for unlimited optimizations.' },
          { status: 402 }
        )
      }

      // Increment usage counter
      await supabaseAdmin
        .from('users')
        .update({ optimizations_used: (user?.optimizations_used || 0) + 1 })
        .eq('id', userId)

      // Log optimization to history
      await supabaseAdmin.from('optimizations').insert({
        user_id: userId,
        resume_snippet: resume.substring(0, 200),
        job_snippet: jobDescription.substring(0, 200),
        created_at: new Date().toISOString()
      })
    }

    const result = await optimizeResume(resume, jobDescription)

    return NextResponse.json({ result })
  } catch (err) {
    console.error('Optimize error:', err)
    return NextResponse.json({ error: 'Something went wrong' }, { status: 500 })
  }
}
