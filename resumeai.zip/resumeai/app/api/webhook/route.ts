import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { supabaseAdmin } from '@/lib/supabase'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: NextRequest) {
  const body = await req.text()
  const sig = req.headers.get('stripe-signature')!

  let event
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err) {
    return NextResponse.json({ error: 'Webhook signature failed' }, { status: 400 })
  }

  // ✅ User subscribed → upgrade them automatically
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as any
    const userId = session.metadata?.userId
    const customerEmail = session.customer_email

    if (userId) {
      await supabaseAdmin
        .from('users')
        .update({
          plan: 'pro',
          stripe_customer_id: session.customer,
          stripe_subscription_id: session.subscription,
          optimizations_used: 0
        })
        .eq('id', userId)

      // Send welcome email automatically
      await resend.emails.send({
        from: 'onboarding@resend.dev',
        to: customerEmail,
        subject: '🎉 You\'re now on Pro — unlimited resume optimizations',
        html: `
          <h2>Welcome to Pro!</h2>
          <p>Your account has been upgraded. You now have unlimited resume optimizations.</p>
          <p><a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard">Go to your dashboard →</a></p>
          <p>Good luck with your job search!</p>
        `
      })
    }
  }

  // ❌ Subscription cancelled → downgrade automatically
  if (event.type === 'customer.subscription.deleted') {
    const subscription = event.data.object as any
    await supabaseAdmin
      .from('users')
      .update({ plan: 'free', optimizations_used: 0 })
      .eq('stripe_subscription_id', subscription.id)
  }

  // 🔄 Payment failed → notify user automatically
  if (event.type === 'invoice.payment_failed') {
    const invoice = event.data.object as any
    const customerEmail = invoice.customer_email

    await resend.emails.send({
      from: 'onboarding@resend.dev',
      to: customerEmail,
      subject: 'Action needed: payment failed',
      html: `
        <p>Your payment failed. Please update your billing details to keep Pro access.</p>
        <p><a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard">Update billing →</a></p>
      `
    })
  }

  return NextResponse.json({ received: true })
}
