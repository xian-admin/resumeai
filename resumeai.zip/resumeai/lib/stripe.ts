import Stripe from 'stripe'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-04-10'
})

export const PLANS = {
  free: {
    name: 'Free',
    optimizations: 3,
    priceId: null,
    price: 0
  },
  pro: {
    name: 'Pro',
    optimizations: 999,
    priceId: process.env.STRIPE_PRO_PRICE_ID,
    price: 9
  }
}
