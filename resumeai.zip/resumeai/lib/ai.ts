import OpenAI from 'openai'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

export async function optimizeResume(resume: string, jobDescription: string) {
  const completion = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'system',
        content: `You are an expert resume coach and ATS specialist with 15 years of experience helping candidates land jobs at top companies. 

Your job is to rewrite and optimize a resume to match a specific job description.

Return your response in this EXACT format:

## MATCH SCORE
X/100 — [one sentence on why]

## OPTIMIZED RESUME
[Full rewritten resume in clean plain text, optimized for ATS and the job description. Use strong action verbs. Quantify achievements. Mirror keywords from the job description naturally.]

## KEY CHANGES MADE
- [change 1]
- [change 2]
- [change 3]
- [change 4]
- [change 5]

## MISSING KEYWORDS
[Comma-separated list of important keywords from the job description not in the original resume]`
      },
      {
        role: 'user',
        content: `JOB DESCRIPTION:\n${jobDescription}\n\nMY RESUME:\n${resume}`
      }
    ],
    max_tokens: 2000,
    temperature: 0.7
  })

  return completion.choices[0].message.content
}
