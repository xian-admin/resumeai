-- Run this in your Supabase SQL Editor

-- Users table (extends Supabase auth.users)
create table public.users (
  id uuid references auth.users(id) primary key,
  email text,
  plan text default 'free',
  optimizations_used integer default 0,
  stripe_customer_id text,
  stripe_subscription_id text,
  created_at timestamp with time zone default now()
);

-- Auto-create user row on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.users (id, email)
  values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Optimizations history
create table public.optimizations (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.users(id),
  resume_snippet text,
  job_snippet text,
  created_at timestamp with time zone default now()
);

-- Enable Row Level Security
alter table public.users enable row level security;
alter table public.optimizations enable row level security;

-- RLS Policies
create policy "Users can read own data"
  on public.users for select
  using (auth.uid() = id);

create policy "Users can read own optimizations"
  on public.optimizations for select
  using (auth.uid() = user_id);
